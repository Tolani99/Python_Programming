This section aims to:
i. Provide the regression function with the computed parameter(in the pdf file)
ii.Compute the empirical risk Rempf for the linear regression and provide the final value in the pdf file
